alter database test character set utf8;
